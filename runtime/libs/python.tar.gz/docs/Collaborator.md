# Collaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user** | [**ShortUser**](ShortUser.md) |  | [optional] 
**permission** | **str** | Permission to the project. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

