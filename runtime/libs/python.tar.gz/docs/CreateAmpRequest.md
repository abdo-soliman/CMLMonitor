# CreateAmpRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create_project_request** | [**CreateProjectRequest**](CreateProjectRequest.md) |  | [optional] 
**configure_prototype_request** | [**ConfigurePrototypeRequest**](ConfigurePrototypeRequest.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

